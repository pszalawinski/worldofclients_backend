package worldofclients.constans;

public class Constans {

    public static final String API_KEY = "&key=AIzaSyC01YfHyvWtoGSemJFaTeEdXgQAPBsU3vY";
    public static final String GEO_SERVICE = "https://maps.googleapis.com/maps/api/geocode/json?address=";

}



// https://maps.googleapis.com/maps/api/geocode/json?address=ZIPCODE+COMPANYNAME,+STREETNAME+STREETNUMBER,+CITY,+COUNTRY&key=AIzaSyC01YfHyvWtoGSemJFaTeEdXgQAPBsU3vY
