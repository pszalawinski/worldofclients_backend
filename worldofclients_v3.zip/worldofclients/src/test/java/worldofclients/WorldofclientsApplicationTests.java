package worldofclients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorldofclientsApplicationTests {

    @Test
    void contextLoads() {
    }

}
